import os
from config import db
from models import Person

# Data to initialize database with
PEOPLE = [
    {"name": "Doug Farrell", "number": "0696070876"},
    {"name": "Kent Brockman", "number": "0696070877"},
    {"name": "Bunny Easter", "number": "0696070878"},
]


# Create the database
db.create_all()

# iterate over the PEOPLE structure and populate the database
for person in PEOPLE:
    p = Person(name=person.get("name"), number=person.get("number"), type=person.get("type"))
    db.session.add(p)

db.session.commit()