<html>
<head>
<title>_collections.py</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
.s0 { color: #8c8c8c; font-style: italic;}
.s1 { color: #080808;}
.s2 { color: #0033b3;}
.s3 { color: #008080; font-weight: bold;}
.s4 { color: #1750eb;}
</style>
</head>
<body bgcolor="#ffffff">
<table CELLSPACING=0 CELLPADDING=5 COLS=1 WIDTH="100%" BGCOLOR="#c0c0c0" >
<tr><td><center>
<font face="Arial, Helvetica" color="#000000">
_collections.py</font>
</center></td></tr></table>
<pre><span class="s0"># util/_collections.py</span>
<span class="s0"># Copyright (C) 2005-2020 the SQLAlchemy authors and contributors</span>
<span class="s0"># &lt;see AUTHORS file&gt;</span>
<span class="s0">#</span>
<span class="s0"># This module is part of SQLAlchemy and is released under</span>
<span class="s0"># the MIT License: http://www.opensource.org/licenses/mit-license.php</span>

<span class="s0">&quot;&quot;&quot;Collection classes and helpers.&quot;&quot;&quot;</span>

<span class="s2">from </span><span class="s1">__future__ </span><span class="s2">import </span><span class="s1">absolute_import</span>

<span class="s2">import </span><span class="s1">operator</span>
<span class="s2">import </span><span class="s1">types</span>
<span class="s2">import </span><span class="s1">weakref</span>

<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">binary_types</span>
<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">collections_abc</span>
<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">itertools_filterfalse</span>
<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">py2k</span>
<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">string_types</span>
<span class="s2">from </span><span class="s1">.compat </span><span class="s2">import </span><span class="s1">threading</span>


<span class="s1">EMPTY_SET = frozenset()</span>


<span class="s2">class </span><span class="s1">AbstractKeyedTuple(tuple):</span>
    <span class="s1">__slots__ = ()</span>

    <span class="s2">def </span><span class="s1">keys(self):</span>
        <span class="s0">&quot;&quot;&quot;Return a list of string key names for this :class:`.KeyedTuple`. 
 
        .. seealso:: 
 
            :attr:`.KeyedTuple._fields` 
 
        &quot;&quot;&quot;</span>

        <span class="s2">return </span><span class="s1">list(self._fields)</span>


<span class="s2">class </span><span class="s1">KeyedTuple(AbstractKeyedTuple):</span>
    <span class="s0">&quot;&quot;&quot;``tuple`` subclass that adds labeled names. 
 
    E.g.:: 
 
        &gt;&gt;&gt; k = KeyedTuple([1, 2, 3], labels=[&quot;one&quot;, &quot;two&quot;, &quot;three&quot;]) 
        &gt;&gt;&gt; k.one 
        1 
        &gt;&gt;&gt; k.two 
        2 
 
    Result rows returned by :class:`_query.Query` that contain multiple 
    ORM entities and/or column expressions make use of this 
    class to return rows. 
 
    The :class:`.KeyedTuple` exhibits similar behavior to the 
    ``collections.namedtuple()`` construct provided in the Python 
    standard library, however is architected very differently. 
    Unlike ``collections.namedtuple()``, :class:`.KeyedTuple` is 
    does not rely on creation of custom subtypes in order to represent 
    a new series of keys, instead each :class:`.KeyedTuple` instance 
    receives its list of keys in place.   The subtype approach 
    of ``collections.namedtuple()`` introduces significant complexity 
    and performance overhead, which is not necessary for the 
    :class:`_query.Query` object's use case. 
 
    .. seealso:: 
 
        :ref:`ormtutorial_querying` 
 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__new__(cls, vals, labels=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">t = tuple.__new__(cls, vals)</span>
        <span class="s2">if </span><span class="s1">labels:</span>
            <span class="s1">t.__dict__.update(zip(labels, vals))</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">labels = []</span>
        <span class="s1">t.__dict__[</span><span class="s3">&quot;_labels&quot;</span><span class="s1">] = labels</span>
        <span class="s2">return </span><span class="s1">t</span>

    <span class="s1">@property</span>
    <span class="s2">def </span><span class="s1">_fields(self):</span>
        <span class="s0">&quot;&quot;&quot;Return a tuple of string key names for this :class:`.KeyedTuple`. 
 
        This method provides compatibility with ``collections.namedtuple()``. 
 
        .. seealso:: 
 
            :meth:`.KeyedTuple.keys` 
 
        &quot;&quot;&quot;</span>
        <span class="s2">return </span><span class="s1">tuple([l </span><span class="s2">for </span><span class="s1">l </span><span class="s2">in </span><span class="s1">self._labels </span><span class="s2">if </span><span class="s1">l </span><span class="s2">is not None</span><span class="s1">])</span>

    <span class="s2">def </span><span class="s1">__setattr__(self, key, value):</span>
        <span class="s2">raise </span><span class="s1">AttributeError(</span><span class="s3">&quot;Can't set attribute: %s&quot; </span><span class="s1">% key)</span>

    <span class="s2">def </span><span class="s1">_asdict(self):</span>
        <span class="s0">&quot;&quot;&quot;Return the contents of this :class:`.KeyedTuple` as a dictionary. 
 
        This method provides compatibility with ``collections.namedtuple()``, 
        with the exception that the dictionary returned is **not** ordered. 
 
        &quot;&quot;&quot;</span>
        <span class="s2">return </span><span class="s1">{key: self.__dict__[key] </span><span class="s2">for </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self.keys()}</span>


<span class="s2">class </span><span class="s1">_LW(AbstractKeyedTuple):</span>
    <span class="s1">__slots__ = ()</span>

    <span class="s2">def </span><span class="s1">__new__(cls, vals):</span>
        <span class="s2">return </span><span class="s1">tuple.__new__(cls, vals)</span>

    <span class="s2">def </span><span class="s1">__reduce__(self):</span>
        <span class="s0"># for pickling, degrade down to the regular</span>
        <span class="s0"># KeyedTuple, thus avoiding anonymous class pickling</span>
        <span class="s0"># difficulties</span>
        <span class="s2">return </span><span class="s1">KeyedTuple, (list(self), self._real_fields)</span>

    <span class="s2">def </span><span class="s1">_asdict(self):</span>
        <span class="s0">&quot;&quot;&quot;Return the contents of this :class:`.KeyedTuple` as a dictionary.&quot;&quot;&quot;</span>

        <span class="s1">d = dict(zip(self._real_fields, self))</span>
        <span class="s1">d.pop(</span><span class="s2">None</span><span class="s1">, </span><span class="s2">None</span><span class="s1">)</span>
        <span class="s2">return </span><span class="s1">d</span>


<span class="s2">class </span><span class="s1">ImmutableContainer(object):</span>
    <span class="s2">def </span><span class="s1">_immutable(self, *arg, **kw):</span>
        <span class="s2">raise </span><span class="s1">TypeError(</span><span class="s3">&quot;%s object is immutable&quot; </span><span class="s1">% self.__class__.__name__)</span>

    <span class="s1">__delitem__ = __setitem__ = __setattr__ = _immutable</span>


<span class="s2">class </span><span class="s1">immutabledict(ImmutableContainer, dict):</span>

    <span class="s1">clear = pop = popitem = setdefault = update = ImmutableContainer._immutable</span>

    <span class="s2">def </span><span class="s1">__new__(cls, *args):</span>
        <span class="s1">new = dict.__new__(cls)</span>
        <span class="s1">dict.__init__(new, *args)</span>
        <span class="s2">return </span><span class="s1">new</span>

    <span class="s2">def </span><span class="s1">__init__(self, *args):</span>
        <span class="s2">pass</span>

    <span class="s2">def </span><span class="s1">__reduce__(self):</span>
        <span class="s2">return </span><span class="s1">immutabledict, (dict(self),)</span>

    <span class="s2">def </span><span class="s1">union(self, d):</span>
        <span class="s2">if not </span><span class="s1">d:</span>
            <span class="s2">return </span><span class="s1">self</span>
        <span class="s2">elif not </span><span class="s1">self:</span>
            <span class="s2">if </span><span class="s1">isinstance(d, immutabledict):</span>
                <span class="s2">return </span><span class="s1">d</span>
            <span class="s2">else</span><span class="s1">:</span>
                <span class="s2">return </span><span class="s1">immutabledict(d)</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">d2 = immutabledict(self)</span>
            <span class="s1">dict.update(d2, d)</span>
            <span class="s2">return </span><span class="s1">d2</span>

    <span class="s2">def </span><span class="s1">__repr__(self):</span>
        <span class="s2">return </span><span class="s3">&quot;immutabledict(%s)&quot; </span><span class="s1">% dict.__repr__(self)</span>


<span class="s2">class </span><span class="s1">Properties(object):</span>
    <span class="s0">&quot;&quot;&quot;Provide a __getattr__/__setattr__ interface over a dict.&quot;&quot;&quot;</span>

    <span class="s1">__slots__ = (</span><span class="s3">&quot;_data&quot;</span><span class="s1">,)</span>

    <span class="s2">def </span><span class="s1">__init__(self, data):</span>
        <span class="s1">object.__setattr__(self, </span><span class="s3">&quot;_data&quot;</span><span class="s1">, data)</span>

    <span class="s2">def </span><span class="s1">__len__(self):</span>
        <span class="s2">return </span><span class="s1">len(self._data)</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">iter(list(self._data.values()))</span>

    <span class="s2">def </span><span class="s1">__dir__(self):</span>
        <span class="s2">return </span><span class="s1">dir(super(Properties, self)) + [</span>
            <span class="s1">str(k) </span><span class="s2">for </span><span class="s1">k </span><span class="s2">in </span><span class="s1">self._data.keys()</span>
        <span class="s1">]</span>

    <span class="s2">def </span><span class="s1">__add__(self, other):</span>
        <span class="s2">return </span><span class="s1">list(self) + list(other)</span>

    <span class="s2">def </span><span class="s1">__setitem__(self, key, obj):</span>
        <span class="s1">self._data[key] = obj</span>

    <span class="s2">def </span><span class="s1">__getitem__(self, key):</span>
        <span class="s2">return </span><span class="s1">self._data[key]</span>

    <span class="s2">def </span><span class="s1">__delitem__(self, key):</span>
        <span class="s2">del </span><span class="s1">self._data[key]</span>

    <span class="s2">def </span><span class="s1">__setattr__(self, key, obj):</span>
        <span class="s1">self._data[key] = obj</span>

    <span class="s2">def </span><span class="s1">__getstate__(self):</span>
        <span class="s2">return </span><span class="s1">{</span><span class="s3">&quot;_data&quot;</span><span class="s1">: self._data}</span>

    <span class="s2">def </span><span class="s1">__setstate__(self, state):</span>
        <span class="s1">object.__setattr__(self, </span><span class="s3">&quot;_data&quot;</span><span class="s1">, state[</span><span class="s3">&quot;_data&quot;</span><span class="s1">])</span>

    <span class="s2">def </span><span class="s1">__getattr__(self, key):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">self._data[key]</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">raise </span><span class="s1">AttributeError(key)</span>

    <span class="s2">def </span><span class="s1">__contains__(self, key):</span>
        <span class="s2">return </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self._data</span>

    <span class="s2">def </span><span class="s1">as_immutable(self):</span>
        <span class="s0">&quot;&quot;&quot;Return an immutable proxy for this :class:`.Properties`.&quot;&quot;&quot;</span>

        <span class="s2">return </span><span class="s1">ImmutableProperties(self._data)</span>

    <span class="s2">def </span><span class="s1">update(self, value):</span>
        <span class="s1">self._data.update(value)</span>

    <span class="s2">def </span><span class="s1">get(self, key, default=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s2">if </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self:</span>
            <span class="s2">return </span><span class="s1">self[key]</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">default</span>

    <span class="s2">def </span><span class="s1">keys(self):</span>
        <span class="s2">return </span><span class="s1">list(self._data)</span>

    <span class="s2">def </span><span class="s1">values(self):</span>
        <span class="s2">return </span><span class="s1">list(self._data.values())</span>

    <span class="s2">def </span><span class="s1">items(self):</span>
        <span class="s2">return </span><span class="s1">list(self._data.items())</span>

    <span class="s2">def </span><span class="s1">has_key(self, key):</span>
        <span class="s2">return </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self._data</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s1">self._data.clear()</span>


<span class="s2">class </span><span class="s1">OrderedProperties(Properties):</span>
    <span class="s0">&quot;&quot;&quot;Provide a __getattr__/__setattr__ interface with an OrderedDict 
    as backing store.&quot;&quot;&quot;</span>

    <span class="s1">__slots__ = ()</span>

    <span class="s2">def </span><span class="s1">__init__(self):</span>
        <span class="s1">Properties.__init__(self, OrderedDict())</span>


<span class="s2">class </span><span class="s1">ImmutableProperties(ImmutableContainer, Properties):</span>
    <span class="s0">&quot;&quot;&quot;Provide immutable dict/object attribute to an underlying dictionary.&quot;&quot;&quot;</span>

    <span class="s1">__slots__ = ()</span>


<span class="s2">class </span><span class="s1">OrderedDict(dict):</span>
    <span class="s0">&quot;&quot;&quot;A dict that returns keys/values/items in the order they were added.&quot;&quot;&quot;</span>

    <span class="s1">__slots__ = (</span><span class="s3">&quot;_list&quot;</span><span class="s1">,)</span>

    <span class="s2">def </span><span class="s1">__reduce__(self):</span>
        <span class="s2">return </span><span class="s1">OrderedDict, (self.items(),)</span>

    <span class="s2">def </span><span class="s1">__init__(self, ____sequence=</span><span class="s2">None</span><span class="s1">, **kwargs):</span>
        <span class="s1">self._list = []</span>
        <span class="s2">if </span><span class="s1">____sequence </span><span class="s2">is None</span><span class="s1">:</span>
            <span class="s2">if </span><span class="s1">kwargs:</span>
                <span class="s1">self.update(**kwargs)</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">self.update(____sequence, **kwargs)</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s1">self._list = []</span>
        <span class="s1">dict.clear(self)</span>

    <span class="s2">def </span><span class="s1">copy(self):</span>
        <span class="s2">return </span><span class="s1">self.__copy__()</span>

    <span class="s2">def </span><span class="s1">__copy__(self):</span>
        <span class="s2">return </span><span class="s1">OrderedDict(self)</span>

    <span class="s2">def </span><span class="s1">sort(self, *arg, **kw):</span>
        <span class="s1">self._list.sort(*arg, **kw)</span>

    <span class="s2">def </span><span class="s1">update(self, ____sequence=</span><span class="s2">None</span><span class="s1">, **kwargs):</span>
        <span class="s2">if </span><span class="s1">____sequence </span><span class="s2">is not None</span><span class="s1">:</span>
            <span class="s2">if </span><span class="s1">hasattr(____sequence, </span><span class="s3">&quot;keys&quot;</span><span class="s1">):</span>
                <span class="s2">for </span><span class="s1">key </span><span class="s2">in </span><span class="s1">____sequence.keys():</span>
                    <span class="s1">self.__setitem__(key, ____sequence[key])</span>
            <span class="s2">else</span><span class="s1">:</span>
                <span class="s2">for </span><span class="s1">key, value </span><span class="s2">in </span><span class="s1">____sequence:</span>
                    <span class="s1">self[key] = value</span>
        <span class="s2">if </span><span class="s1">kwargs:</span>
            <span class="s1">self.update(kwargs)</span>

    <span class="s2">def </span><span class="s1">setdefault(self, key, value):</span>
        <span class="s2">if </span><span class="s1">key </span><span class="s2">not in </span><span class="s1">self:</span>
            <span class="s1">self.__setitem__(key, value)</span>
            <span class="s2">return </span><span class="s1">value</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">self.__getitem__(key)</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">iter(self._list)</span>

    <span class="s2">def </span><span class="s1">keys(self):</span>
        <span class="s2">return </span><span class="s1">list(self)</span>

    <span class="s2">def </span><span class="s1">values(self):</span>
        <span class="s2">return </span><span class="s1">[self[key] </span><span class="s2">for </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self._list]</span>

    <span class="s2">def </span><span class="s1">items(self):</span>
        <span class="s2">return </span><span class="s1">[(key, self[key]) </span><span class="s2">for </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self._list]</span>

    <span class="s2">if </span><span class="s1">py2k:</span>

        <span class="s2">def </span><span class="s1">itervalues(self):</span>
            <span class="s2">return </span><span class="s1">iter(self.values())</span>

        <span class="s2">def </span><span class="s1">iterkeys(self):</span>
            <span class="s2">return </span><span class="s1">iter(self)</span>

        <span class="s2">def </span><span class="s1">iteritems(self):</span>
            <span class="s2">return </span><span class="s1">iter(self.items())</span>

    <span class="s2">def </span><span class="s1">__setitem__(self, key, obj):</span>
        <span class="s2">if </span><span class="s1">key </span><span class="s2">not in </span><span class="s1">self:</span>
            <span class="s2">try</span><span class="s1">:</span>
                <span class="s1">self._list.append(key)</span>
            <span class="s2">except </span><span class="s1">AttributeError:</span>
                <span class="s0"># work around Python pickle loads() with</span>
                <span class="s0"># dict subclass (seems to ignore __setstate__?)</span>
                <span class="s1">self._list = [key]</span>
        <span class="s1">dict.__setitem__(self, key, obj)</span>

    <span class="s2">def </span><span class="s1">__delitem__(self, key):</span>
        <span class="s1">dict.__delitem__(self, key)</span>
        <span class="s1">self._list.remove(key)</span>

    <span class="s2">def </span><span class="s1">pop(self, key, *default):</span>
        <span class="s1">present = key </span><span class="s2">in </span><span class="s1">self</span>
        <span class="s1">value = dict.pop(self, key, *default)</span>
        <span class="s2">if </span><span class="s1">present:</span>
            <span class="s1">self._list.remove(key)</span>
        <span class="s2">return </span><span class="s1">value</span>

    <span class="s2">def </span><span class="s1">popitem(self):</span>
        <span class="s1">item = dict.popitem(self)</span>
        <span class="s1">self._list.remove(item[</span><span class="s4">0</span><span class="s1">])</span>
        <span class="s2">return </span><span class="s1">item</span>


<span class="s2">class </span><span class="s1">OrderedSet(set):</span>
    <span class="s2">def </span><span class="s1">__init__(self, d=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">set.__init__(self)</span>
        <span class="s1">self._list = []</span>
        <span class="s2">if </span><span class="s1">d </span><span class="s2">is not None</span><span class="s1">:</span>
            <span class="s1">self._list = unique_list(d)</span>
            <span class="s1">set.update(self, self._list)</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">self._list = []</span>

    <span class="s2">def </span><span class="s1">add(self, element):</span>
        <span class="s2">if </span><span class="s1">element </span><span class="s2">not in </span><span class="s1">self:</span>
            <span class="s1">self._list.append(element)</span>
        <span class="s1">set.add(self, element)</span>

    <span class="s2">def </span><span class="s1">remove(self, element):</span>
        <span class="s1">set.remove(self, element)</span>
        <span class="s1">self._list.remove(element)</span>

    <span class="s2">def </span><span class="s1">insert(self, pos, element):</span>
        <span class="s2">if </span><span class="s1">element </span><span class="s2">not in </span><span class="s1">self:</span>
            <span class="s1">self._list.insert(pos, element)</span>
        <span class="s1">set.add(self, element)</span>

    <span class="s2">def </span><span class="s1">discard(self, element):</span>
        <span class="s2">if </span><span class="s1">element </span><span class="s2">in </span><span class="s1">self:</span>
            <span class="s1">self._list.remove(element)</span>
            <span class="s1">set.remove(self, element)</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s1">set.clear(self)</span>
        <span class="s1">self._list = []</span>

    <span class="s2">def </span><span class="s1">__getitem__(self, key):</span>
        <span class="s2">return </span><span class="s1">self._list[key]</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">iter(self._list)</span>

    <span class="s2">def </span><span class="s1">__add__(self, other):</span>
        <span class="s2">return </span><span class="s1">self.union(other)</span>

    <span class="s2">def </span><span class="s1">__repr__(self):</span>
        <span class="s2">return </span><span class="s3">&quot;%s(%r)&quot; </span><span class="s1">% (self.__class__.__name__, self._list)</span>

    <span class="s1">__str__ = __repr__</span>

    <span class="s2">def </span><span class="s1">update(self, iterable):</span>
        <span class="s2">for </span><span class="s1">e </span><span class="s2">in </span><span class="s1">iterable:</span>
            <span class="s2">if </span><span class="s1">e </span><span class="s2">not in </span><span class="s1">self:</span>
                <span class="s1">self._list.append(e)</span>
                <span class="s1">set.add(self, e)</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s1">__ior__ = update</span>

    <span class="s2">def </span><span class="s1">union(self, other):</span>
        <span class="s1">result = self.__class__(self)</span>
        <span class="s1">result.update(other)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s1">__or__ = union</span>

    <span class="s2">def </span><span class="s1">intersection(self, other):</span>
        <span class="s1">other = set(other)</span>
        <span class="s2">return </span><span class="s1">self.__class__(a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self </span><span class="s2">if </span><span class="s1">a </span><span class="s2">in </span><span class="s1">other)</span>

    <span class="s1">__and__ = intersection</span>

    <span class="s2">def </span><span class="s1">symmetric_difference(self, other):</span>
        <span class="s1">other = set(other)</span>
        <span class="s1">result = self.__class__(a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self </span><span class="s2">if </span><span class="s1">a </span><span class="s2">not in </span><span class="s1">other)</span>
        <span class="s1">result.update(a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">other </span><span class="s2">if </span><span class="s1">a </span><span class="s2">not in </span><span class="s1">self)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s1">__xor__ = symmetric_difference</span>

    <span class="s2">def </span><span class="s1">difference(self, other):</span>
        <span class="s1">other = set(other)</span>
        <span class="s2">return </span><span class="s1">self.__class__(a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self </span><span class="s2">if </span><span class="s1">a </span><span class="s2">not in </span><span class="s1">other)</span>

    <span class="s1">__sub__ = difference</span>

    <span class="s2">def </span><span class="s1">intersection_update(self, other):</span>
        <span class="s1">other = set(other)</span>
        <span class="s1">set.intersection_update(self, other)</span>
        <span class="s1">self._list = [a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self._list </span><span class="s2">if </span><span class="s1">a </span><span class="s2">in </span><span class="s1">other]</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s1">__iand__ = intersection_update</span>

    <span class="s2">def </span><span class="s1">symmetric_difference_update(self, other):</span>
        <span class="s1">set.symmetric_difference_update(self, other)</span>
        <span class="s1">self._list = [a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self._list </span><span class="s2">if </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self]</span>
        <span class="s1">self._list += [a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">other._list </span><span class="s2">if </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self]</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s1">__ixor__ = symmetric_difference_update</span>

    <span class="s2">def </span><span class="s1">difference_update(self, other):</span>
        <span class="s1">set.difference_update(self, other)</span>
        <span class="s1">self._list = [a </span><span class="s2">for </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self._list </span><span class="s2">if </span><span class="s1">a </span><span class="s2">in </span><span class="s1">self]</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s1">__isub__ = difference_update</span>


<span class="s2">class </span><span class="s1">IdentitySet(object):</span>
    <span class="s0">&quot;&quot;&quot;A set that considers only object id() for uniqueness. 
 
    This strategy has edge cases for builtin types- it's possible to have 
    two 'foo' strings in one of these sets, for example.  Use sparingly. 
 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, iterable=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">self._members = dict()</span>
        <span class="s2">if </span><span class="s1">iterable:</span>
            <span class="s1">self.update(iterable)</span>

    <span class="s2">def </span><span class="s1">add(self, value):</span>
        <span class="s1">self._members[id(value)] = value</span>

    <span class="s2">def </span><span class="s1">__contains__(self, value):</span>
        <span class="s2">return </span><span class="s1">id(value) </span><span class="s2">in </span><span class="s1">self._members</span>

    <span class="s2">def </span><span class="s1">remove(self, value):</span>
        <span class="s2">del </span><span class="s1">self._members[id(value)]</span>

    <span class="s2">def </span><span class="s1">discard(self, value):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s1">self.remove(value)</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">pass</span>

    <span class="s2">def </span><span class="s1">pop(self):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s1">pair = self._members.popitem()</span>
            <span class="s2">return </span><span class="s1">pair[</span><span class="s4">1</span><span class="s1">]</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">raise </span><span class="s1">KeyError(</span><span class="s3">&quot;pop from an empty set&quot;</span><span class="s1">)</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s1">self._members.clear()</span>

    <span class="s2">def </span><span class="s1">__cmp__(self, other):</span>
        <span class="s2">raise </span><span class="s1">TypeError(</span><span class="s3">&quot;cannot compare sets using cmp()&quot;</span><span class="s1">)</span>

    <span class="s2">def </span><span class="s1">__eq__(self, other):</span>
        <span class="s2">if </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">self._members == other._members</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return False</span>

    <span class="s2">def </span><span class="s1">__ne__(self, other):</span>
        <span class="s2">if </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">self._members != other._members</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return True</span>

    <span class="s2">def </span><span class="s1">issubset(self, iterable):</span>
        <span class="s1">other = self.__class__(iterable)</span>

        <span class="s2">if </span><span class="s1">len(self) &gt; len(other):</span>
            <span class="s2">return False</span>
        <span class="s2">for </span><span class="s1">m </span><span class="s2">in </span><span class="s1">itertools_filterfalse(</span>
            <span class="s1">other._members.__contains__, iter(self._members.keys())</span>
        <span class="s1">):</span>
            <span class="s2">return False</span>
        <span class="s2">return True</span>

    <span class="s2">def </span><span class="s1">__le__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.issubset(other)</span>

    <span class="s2">def </span><span class="s1">__lt__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">len(self) &lt; len(other) </span><span class="s2">and </span><span class="s1">self.issubset(other)</span>

    <span class="s2">def </span><span class="s1">issuperset(self, iterable):</span>
        <span class="s1">other = self.__class__(iterable)</span>

        <span class="s2">if </span><span class="s1">len(self) &lt; len(other):</span>
            <span class="s2">return False</span>

        <span class="s2">for </span><span class="s1">m </span><span class="s2">in </span><span class="s1">itertools_filterfalse(</span>
            <span class="s1">self._members.__contains__, iter(other._members.keys())</span>
        <span class="s1">):</span>
            <span class="s2">return False</span>
        <span class="s2">return True</span>

    <span class="s2">def </span><span class="s1">__ge__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.issuperset(other)</span>

    <span class="s2">def </span><span class="s1">__gt__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">len(self) &gt; len(other) </span><span class="s2">and </span><span class="s1">self.issuperset(other)</span>

    <span class="s2">def </span><span class="s1">union(self, iterable):</span>
        <span class="s1">result = self.__class__()</span>
        <span class="s1">members = self._members</span>
        <span class="s1">result._members.update(members)</span>
        <span class="s1">result._members.update((id(obj), obj) </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">iterable)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s2">def </span><span class="s1">__or__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.union(other)</span>

    <span class="s2">def </span><span class="s1">update(self, iterable):</span>
        <span class="s1">self._members.update((id(obj), obj) </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">iterable)</span>

    <span class="s2">def </span><span class="s1">__ior__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s1">self.update(other)</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s2">def </span><span class="s1">difference(self, iterable):</span>
        <span class="s1">result = self.__class__()</span>
        <span class="s1">members = self._members</span>
        <span class="s1">other = {id(obj) </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">iterable}</span>
        <span class="s1">result._members.update(</span>
            <span class="s1">((k, v) </span><span class="s2">for </span><span class="s1">k, v </span><span class="s2">in </span><span class="s1">members.items() </span><span class="s2">if </span><span class="s1">k </span><span class="s2">not in </span><span class="s1">other)</span>
        <span class="s1">)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s2">def </span><span class="s1">__sub__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.difference(other)</span>

    <span class="s2">def </span><span class="s1">difference_update(self, iterable):</span>
        <span class="s1">self._members = self.difference(iterable)._members</span>

    <span class="s2">def </span><span class="s1">__isub__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s1">self.difference_update(other)</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s2">def </span><span class="s1">intersection(self, iterable):</span>
        <span class="s1">result = self.__class__()</span>
        <span class="s1">members = self._members</span>
        <span class="s1">other = {id(obj) </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">iterable}</span>
        <span class="s1">result._members.update(</span>
            <span class="s1">(k, v) </span><span class="s2">for </span><span class="s1">k, v </span><span class="s2">in </span><span class="s1">members.items() </span><span class="s2">if </span><span class="s1">k </span><span class="s2">in </span><span class="s1">other</span>
        <span class="s1">)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s2">def </span><span class="s1">__and__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.intersection(other)</span>

    <span class="s2">def </span><span class="s1">intersection_update(self, iterable):</span>
        <span class="s1">self._members = self.intersection(iterable)._members</span>

    <span class="s2">def </span><span class="s1">__iand__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s1">self.intersection_update(other)</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s2">def </span><span class="s1">symmetric_difference(self, iterable):</span>
        <span class="s1">result = self.__class__()</span>
        <span class="s1">members = self._members</span>
        <span class="s1">other = {id(obj): obj </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">iterable}</span>
        <span class="s1">result._members.update(</span>
            <span class="s1">((k, v) </span><span class="s2">for </span><span class="s1">k, v </span><span class="s2">in </span><span class="s1">members.items() </span><span class="s2">if </span><span class="s1">k </span><span class="s2">not in </span><span class="s1">other)</span>
        <span class="s1">)</span>
        <span class="s1">result._members.update(</span>
            <span class="s1">((k, v) </span><span class="s2">for </span><span class="s1">k, v </span><span class="s2">in </span><span class="s1">other.items() </span><span class="s2">if </span><span class="s1">k </span><span class="s2">not in </span><span class="s1">members)</span>
        <span class="s1">)</span>
        <span class="s2">return </span><span class="s1">result</span>

    <span class="s2">def </span><span class="s1">__xor__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s2">return </span><span class="s1">self.symmetric_difference(other)</span>

    <span class="s2">def </span><span class="s1">symmetric_difference_update(self, iterable):</span>
        <span class="s1">self._members = self.symmetric_difference(iterable)._members</span>

    <span class="s2">def </span><span class="s1">__ixor__(self, other):</span>
        <span class="s2">if not </span><span class="s1">isinstance(other, IdentitySet):</span>
            <span class="s2">return </span><span class="s1">NotImplemented</span>
        <span class="s1">self.symmetric_difference(other)</span>
        <span class="s2">return </span><span class="s1">self</span>

    <span class="s2">def </span><span class="s1">copy(self):</span>
        <span class="s2">return </span><span class="s1">type(self)(iter(self._members.values()))</span>

    <span class="s1">__copy__ = copy</span>

    <span class="s2">def </span><span class="s1">__len__(self):</span>
        <span class="s2">return </span><span class="s1">len(self._members)</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">iter(self._members.values())</span>

    <span class="s2">def </span><span class="s1">__hash__(self):</span>
        <span class="s2">raise </span><span class="s1">TypeError(</span><span class="s3">&quot;set objects are unhashable&quot;</span><span class="s1">)</span>

    <span class="s2">def </span><span class="s1">__repr__(self):</span>
        <span class="s2">return </span><span class="s3">&quot;%s(%r)&quot; </span><span class="s1">% (type(self).__name__, list(self._members.values()))</span>


<span class="s2">class </span><span class="s1">WeakSequence(object):</span>
    <span class="s2">def </span><span class="s1">__init__(self, __elements=()):</span>
        <span class="s0"># adapted from weakref.WeakKeyDictionary, prevent reference</span>
        <span class="s0"># cycles in the collection itself</span>
        <span class="s2">def </span><span class="s1">_remove(item, selfref=weakref.ref(self)):</span>
            <span class="s1">self = selfref()</span>
            <span class="s2">if </span><span class="s1">self </span><span class="s2">is not None</span><span class="s1">:</span>
                <span class="s1">self._storage.remove(item)</span>

        <span class="s1">self._remove = _remove</span>
        <span class="s1">self._storage = [</span>
            <span class="s1">weakref.ref(element, _remove) </span><span class="s2">for </span><span class="s1">element </span><span class="s2">in </span><span class="s1">__elements</span>
        <span class="s1">]</span>

    <span class="s2">def </span><span class="s1">append(self, item):</span>
        <span class="s1">self._storage.append(weakref.ref(item, self._remove))</span>

    <span class="s2">def </span><span class="s1">__len__(self):</span>
        <span class="s2">return </span><span class="s1">len(self._storage)</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">(</span>
            <span class="s1">obj </span><span class="s2">for </span><span class="s1">obj </span><span class="s2">in </span><span class="s1">(ref() </span><span class="s2">for </span><span class="s1">ref </span><span class="s2">in </span><span class="s1">self._storage) </span><span class="s2">if </span><span class="s1">obj </span><span class="s2">is not None</span>
        <span class="s1">)</span>

    <span class="s2">def </span><span class="s1">__getitem__(self, index):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s1">obj = self._storage[index]</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">raise </span><span class="s1">IndexError(</span><span class="s3">&quot;Index %s out of range&quot; </span><span class="s1">% index)</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">obj()</span>


<span class="s2">class </span><span class="s1">OrderedIdentitySet(IdentitySet):</span>
    <span class="s2">def </span><span class="s1">__init__(self, iterable=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">IdentitySet.__init__(self)</span>
        <span class="s1">self._members = OrderedDict()</span>
        <span class="s2">if </span><span class="s1">iterable:</span>
            <span class="s2">for </span><span class="s1">o </span><span class="s2">in </span><span class="s1">iterable:</span>
                <span class="s1">self.add(o)</span>


<span class="s2">class </span><span class="s1">PopulateDict(dict):</span>
    <span class="s0">&quot;&quot;&quot;A dict which populates missing values via a creation function. 
 
    Note the creation function takes a key, unlike 
    collections.defaultdict. 
 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, creator):</span>
        <span class="s1">self.creator = creator</span>

    <span class="s2">def </span><span class="s1">__missing__(self, key):</span>
        <span class="s1">self[key] = val = self.creator(key)</span>
        <span class="s2">return </span><span class="s1">val</span>


<span class="s2">class </span><span class="s1">WeakPopulateDict(dict):</span>
    <span class="s0">&quot;&quot;&quot;Like PopulateDict, but assumes a self + a method and does not create 
    a reference cycle. 
 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, creator_method):</span>
        <span class="s1">self.creator = creator_method.__func__</span>
        <span class="s1">weakself = creator_method.__self__</span>
        <span class="s1">self.weakself = weakref.ref(weakself)</span>

    <span class="s2">def </span><span class="s1">__missing__(self, key):</span>
        <span class="s1">self[key] = val = self.creator(self.weakself(), key)</span>
        <span class="s2">return </span><span class="s1">val</span>


<span class="s0"># Define collections that are capable of storing</span>
<span class="s0"># ColumnElement objects as hashable keys/elements.</span>
<span class="s0"># At this point, these are mostly historical, things</span>
<span class="s0"># used to be more complicated.</span>
<span class="s1">column_set = set</span>
<span class="s1">column_dict = dict</span>
<span class="s1">ordered_column_set = OrderedSet</span>


<span class="s1">_getters = PopulateDict(operator.itemgetter)</span>

<span class="s1">_property_getters = PopulateDict(</span>
    <span class="s2">lambda </span><span class="s1">idx: property(operator.itemgetter(idx))</span>
<span class="s1">)</span>


<span class="s2">def </span><span class="s1">unique_list(seq, hashfunc=</span><span class="s2">None</span><span class="s1">):</span>
    <span class="s1">seen = set()</span>
    <span class="s1">seen_add = seen.add</span>
    <span class="s2">if not </span><span class="s1">hashfunc:</span>
        <span class="s2">return </span><span class="s1">[x </span><span class="s2">for </span><span class="s1">x </span><span class="s2">in </span><span class="s1">seq </span><span class="s2">if </span><span class="s1">x </span><span class="s2">not in </span><span class="s1">seen </span><span class="s2">and not </span><span class="s1">seen_add(x)]</span>
    <span class="s2">else</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">[</span>
            <span class="s1">x</span>
            <span class="s2">for </span><span class="s1">x </span><span class="s2">in </span><span class="s1">seq</span>
            <span class="s2">if </span><span class="s1">hashfunc(x) </span><span class="s2">not in </span><span class="s1">seen </span><span class="s2">and not </span><span class="s1">seen_add(hashfunc(x))</span>
        <span class="s1">]</span>


<span class="s2">class </span><span class="s1">UniqueAppender(object):</span>
    <span class="s0">&quot;&quot;&quot;Appends items to a collection ensuring uniqueness. 
 
    Additional appends() of the same object are ignored.  Membership is 
    determined by identity (``is a``) not equality (``==``). 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, data, via=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">self.data = data</span>
        <span class="s1">self._unique = {}</span>
        <span class="s2">if </span><span class="s1">via:</span>
            <span class="s1">self._data_appender = getattr(data, via)</span>
        <span class="s2">elif </span><span class="s1">hasattr(data, </span><span class="s3">&quot;append&quot;</span><span class="s1">):</span>
            <span class="s1">self._data_appender = data.append</span>
        <span class="s2">elif </span><span class="s1">hasattr(data, </span><span class="s3">&quot;add&quot;</span><span class="s1">):</span>
            <span class="s1">self._data_appender = data.add</span>

    <span class="s2">def </span><span class="s1">append(self, item):</span>
        <span class="s1">id_ = id(item)</span>
        <span class="s2">if </span><span class="s1">id_ </span><span class="s2">not in </span><span class="s1">self._unique:</span>
            <span class="s1">self._data_appender(item)</span>
            <span class="s1">self._unique[id_] = </span><span class="s2">True</span>

    <span class="s2">def </span><span class="s1">__iter__(self):</span>
        <span class="s2">return </span><span class="s1">iter(self.data)</span>


<span class="s2">def </span><span class="s1">coerce_generator_arg(arg):</span>
    <span class="s2">if </span><span class="s1">len(arg) == </span><span class="s4">1 </span><span class="s2">and </span><span class="s1">isinstance(arg[</span><span class="s4">0</span><span class="s1">], types.GeneratorType):</span>
        <span class="s2">return </span><span class="s1">list(arg[</span><span class="s4">0</span><span class="s1">])</span>
    <span class="s2">else</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">arg</span>


<span class="s2">def </span><span class="s1">to_list(x, default=</span><span class="s2">None</span><span class="s1">):</span>
    <span class="s2">if </span><span class="s1">x </span><span class="s2">is None</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">default</span>
    <span class="s2">if not </span><span class="s1">isinstance(x, collections_abc.Iterable) </span><span class="s2">or </span><span class="s1">isinstance(</span>
        <span class="s1">x, string_types + binary_types</span>
    <span class="s1">):</span>
        <span class="s2">return </span><span class="s1">[x]</span>
    <span class="s2">elif </span><span class="s1">isinstance(x, list):</span>
        <span class="s2">return </span><span class="s1">x</span>
    <span class="s2">else</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">list(x)</span>


<span class="s2">def </span><span class="s1">has_intersection(set_, iterable):</span>
    <span class="s0">r&quot;&quot;&quot;return True if any items of set\_ are present in iterable. 
 
    Goes through special effort to ensure __hash__ is not called 
    on items in iterable that don't support it. 
 
    &quot;&quot;&quot;</span>
    <span class="s0"># TODO: optimize, write in C, etc.</span>
    <span class="s2">return </span><span class="s1">bool(set_.intersection([i </span><span class="s2">for </span><span class="s1">i </span><span class="s2">in </span><span class="s1">iterable </span><span class="s2">if </span><span class="s1">i.__hash__]))</span>


<span class="s2">def </span><span class="s1">to_set(x):</span>
    <span class="s2">if </span><span class="s1">x </span><span class="s2">is None</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">set()</span>
    <span class="s2">if not </span><span class="s1">isinstance(x, set):</span>
        <span class="s2">return </span><span class="s1">set(to_list(x))</span>
    <span class="s2">else</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">x</span>


<span class="s2">def </span><span class="s1">to_column_set(x):</span>
    <span class="s2">if </span><span class="s1">x </span><span class="s2">is None</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">column_set()</span>
    <span class="s2">if not </span><span class="s1">isinstance(x, column_set):</span>
        <span class="s2">return </span><span class="s1">column_set(to_list(x))</span>
    <span class="s2">else</span><span class="s1">:</span>
        <span class="s2">return </span><span class="s1">x</span>


<span class="s2">def </span><span class="s1">update_copy(d, _new=</span><span class="s2">None</span><span class="s1">, **kw):</span>
    <span class="s0">&quot;&quot;&quot;Copy the given dict and update with the given values.&quot;&quot;&quot;</span>

    <span class="s1">d = d.copy()</span>
    <span class="s2">if </span><span class="s1">_new:</span>
        <span class="s1">d.update(_new)</span>
    <span class="s1">d.update(**kw)</span>
    <span class="s2">return </span><span class="s1">d</span>


<span class="s2">def </span><span class="s1">flatten_iterator(x):</span>
    <span class="s0">&quot;&quot;&quot;Given an iterator of which further sub-elements may also be 
    iterators, flatten the sub-elements into a single iterator. 
 
    &quot;&quot;&quot;</span>
    <span class="s2">for </span><span class="s1">elem </span><span class="s2">in </span><span class="s1">x:</span>
        <span class="s2">if not </span><span class="s1">isinstance(elem, str) </span><span class="s2">and </span><span class="s1">hasattr(elem, </span><span class="s3">&quot;__iter__&quot;</span><span class="s1">):</span>
            <span class="s2">for </span><span class="s1">y </span><span class="s2">in </span><span class="s1">flatten_iterator(elem):</span>
                <span class="s2">yield </span><span class="s1">y</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">yield </span><span class="s1">elem</span>


<span class="s2">class </span><span class="s1">LRUCache(dict):</span>
    <span class="s0">&quot;&quot;&quot;Dictionary with 'squishy' removal of least 
    recently used items. 
 
    Note that either get() or [] should be used here, but 
    generally its not safe to do an &quot;in&quot; check first as the dictionary 
    can change subsequent to that call. 
 
    &quot;&quot;&quot;</span>

    <span class="s1">__slots__ = </span><span class="s3">&quot;capacity&quot;</span><span class="s1">, </span><span class="s3">&quot;threshold&quot;</span><span class="s1">, </span><span class="s3">&quot;size_alert&quot;</span><span class="s1">, </span><span class="s3">&quot;_counter&quot;</span><span class="s1">, </span><span class="s3">&quot;_mutex&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, capacity=</span><span class="s4">100</span><span class="s1">, threshold=</span><span class="s4">0.5</span><span class="s1">, size_alert=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">self.capacity = capacity</span>
        <span class="s1">self.threshold = threshold</span>
        <span class="s1">self.size_alert = size_alert</span>
        <span class="s1">self._counter = </span><span class="s4">0</span>
        <span class="s1">self._mutex = threading.Lock()</span>

    <span class="s2">def </span><span class="s1">_inc_counter(self):</span>
        <span class="s1">self._counter += </span><span class="s4">1</span>
        <span class="s2">return </span><span class="s1">self._counter</span>

    <span class="s2">def </span><span class="s1">get(self, key, default=</span><span class="s2">None</span><span class="s1">):</span>
        <span class="s1">item = dict.get(self, key, default)</span>
        <span class="s2">if </span><span class="s1">item </span><span class="s2">is not </span><span class="s1">default:</span>
            <span class="s1">item[</span><span class="s4">2</span><span class="s1">] = self._inc_counter()</span>
            <span class="s2">return </span><span class="s1">item[</span><span class="s4">1</span><span class="s1">]</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">default</span>

    <span class="s2">def </span><span class="s1">__getitem__(self, key):</span>
        <span class="s1">item = dict.__getitem__(self, key)</span>
        <span class="s1">item[</span><span class="s4">2</span><span class="s1">] = self._inc_counter()</span>
        <span class="s2">return </span><span class="s1">item[</span><span class="s4">1</span><span class="s1">]</span>

    <span class="s2">def </span><span class="s1">values(self):</span>
        <span class="s2">return </span><span class="s1">[i[</span><span class="s4">1</span><span class="s1">] </span><span class="s2">for </span><span class="s1">i </span><span class="s2">in </span><span class="s1">dict.values(self)]</span>

    <span class="s2">def </span><span class="s1">setdefault(self, key, value):</span>
        <span class="s2">if </span><span class="s1">key </span><span class="s2">in </span><span class="s1">self:</span>
            <span class="s2">return </span><span class="s1">self[key]</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">self[key] = value</span>
            <span class="s2">return </span><span class="s1">value</span>

    <span class="s2">def </span><span class="s1">__setitem__(self, key, value):</span>
        <span class="s1">item = dict.get(self, key)</span>
        <span class="s2">if </span><span class="s1">item </span><span class="s2">is None</span><span class="s1">:</span>
            <span class="s1">item = [key, value, self._inc_counter()]</span>
            <span class="s1">dict.__setitem__(self, key, item)</span>
        <span class="s2">else</span><span class="s1">:</span>
            <span class="s1">item[</span><span class="s4">1</span><span class="s1">] = value</span>
        <span class="s1">self._manage_size()</span>

    <span class="s1">@property</span>
    <span class="s2">def </span><span class="s1">size_threshold(self):</span>
        <span class="s2">return </span><span class="s1">self.capacity + self.capacity * self.threshold</span>

    <span class="s2">def </span><span class="s1">_manage_size(self):</span>
        <span class="s2">if not </span><span class="s1">self._mutex.acquire(</span><span class="s2">False</span><span class="s1">):</span>
            <span class="s2">return</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s1">size_alert = bool(self.size_alert)</span>
            <span class="s2">while </span><span class="s1">len(self) &gt; self.capacity + self.capacity * self.threshold:</span>
                <span class="s2">if </span><span class="s1">size_alert:</span>
                    <span class="s1">size_alert = </span><span class="s2">False</span>
                    <span class="s1">self.size_alert(self)</span>
                <span class="s1">by_counter = sorted(</span>
                    <span class="s1">dict.values(self), key=operator.itemgetter(</span><span class="s4">2</span><span class="s1">), reverse=</span><span class="s2">True</span>
                <span class="s1">)</span>
                <span class="s2">for </span><span class="s1">item </span><span class="s2">in </span><span class="s1">by_counter[self.capacity :]:</span>
                    <span class="s2">try</span><span class="s1">:</span>
                        <span class="s2">del </span><span class="s1">self[item[</span><span class="s4">0</span><span class="s1">]]</span>
                    <span class="s2">except </span><span class="s1">KeyError:</span>
                        <span class="s0"># deleted elsewhere; skip</span>
                        <span class="s2">continue</span>
        <span class="s2">finally</span><span class="s1">:</span>
            <span class="s1">self._mutex.release()</span>


<span class="s1">_lw_tuples = LRUCache(</span><span class="s4">100</span><span class="s1">)</span>


<span class="s2">def </span><span class="s1">lightweight_named_tuple(name, fields):</span>
    <span class="s1">hash_ = (name,) + tuple(fields)</span>
    <span class="s1">tp_cls = _lw_tuples.get(hash_)</span>
    <span class="s2">if </span><span class="s1">tp_cls:</span>
        <span class="s2">return </span><span class="s1">tp_cls</span>

    <span class="s1">tp_cls = type(</span>
        <span class="s1">name,</span>
        <span class="s1">(_LW,),</span>
        <span class="s1">dict(</span>
            <span class="s1">[</span>
                <span class="s1">(field, _property_getters[idx])</span>
                <span class="s2">for </span><span class="s1">idx, field </span><span class="s2">in </span><span class="s1">enumerate(fields)</span>
                <span class="s2">if </span><span class="s1">field </span><span class="s2">is not None</span>
            <span class="s1">]</span>
            <span class="s1">+ [(</span><span class="s3">&quot;__slots__&quot;</span><span class="s1">, ())]</span>
        <span class="s1">),</span>
    <span class="s1">)</span>

    <span class="s1">tp_cls._real_fields = fields</span>
    <span class="s1">tp_cls._fields = tuple([f </span><span class="s2">for </span><span class="s1">f </span><span class="s2">in </span><span class="s1">fields </span><span class="s2">if </span><span class="s1">f </span><span class="s2">is not None</span><span class="s1">])</span>

    <span class="s1">_lw_tuples[hash_] = tp_cls</span>
    <span class="s2">return </span><span class="s1">tp_cls</span>


<span class="s2">class </span><span class="s1">ScopedRegistry(object):</span>
    <span class="s0">&quot;&quot;&quot;A Registry that can store one or multiple instances of a single 
    class on the basis of a &quot;scope&quot; function. 
 
    The object implements ``__call__`` as the &quot;getter&quot;, so by 
    calling ``myregistry()`` the contained object is returned 
    for the current scope. 
 
    :param createfunc: 
      a callable that returns a new object to be placed in the registry 
 
    :param scopefunc: 
      a callable that will return a key to store/retrieve an object. 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, createfunc, scopefunc):</span>
        <span class="s0">&quot;&quot;&quot;Construct a new :class:`.ScopedRegistry`. 
 
        :param createfunc:  A creation function that will generate 
          a new value for the current scope, if none is present. 
 
        :param scopefunc:  A function that returns a hashable 
          token representing the current scope (such as, current 
          thread identifier). 
 
        &quot;&quot;&quot;</span>
        <span class="s1">self.createfunc = createfunc</span>
        <span class="s1">self.scopefunc = scopefunc</span>
        <span class="s1">self.registry = {}</span>

    <span class="s2">def </span><span class="s1">__call__(self):</span>
        <span class="s1">key = self.scopefunc()</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">self.registry[key]</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">return </span><span class="s1">self.registry.setdefault(key, self.createfunc())</span>

    <span class="s2">def </span><span class="s1">has(self):</span>
        <span class="s0">&quot;&quot;&quot;Return True if an object is present in the current scope.&quot;&quot;&quot;</span>

        <span class="s2">return </span><span class="s1">self.scopefunc() </span><span class="s2">in </span><span class="s1">self.registry</span>

    <span class="s2">def </span><span class="s1">set(self, obj):</span>
        <span class="s0">&quot;&quot;&quot;Set the value for the current scope.&quot;&quot;&quot;</span>

        <span class="s1">self.registry[self.scopefunc()] = obj</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s0">&quot;&quot;&quot;Clear the current scope, if any.&quot;&quot;&quot;</span>

        <span class="s2">try</span><span class="s1">:</span>
            <span class="s2">del </span><span class="s1">self.registry[self.scopefunc()]</span>
        <span class="s2">except </span><span class="s1">KeyError:</span>
            <span class="s2">pass</span>


<span class="s2">class </span><span class="s1">ThreadLocalRegistry(ScopedRegistry):</span>
    <span class="s0">&quot;&quot;&quot;A :class:`.ScopedRegistry` that uses a ``threading.local()`` 
    variable for storage. 
 
    &quot;&quot;&quot;</span>

    <span class="s2">def </span><span class="s1">__init__(self, createfunc):</span>
        <span class="s1">self.createfunc = createfunc</span>
        <span class="s1">self.registry = threading.local()</span>

    <span class="s2">def </span><span class="s1">__call__(self):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s2">return </span><span class="s1">self.registry.value</span>
        <span class="s2">except </span><span class="s1">AttributeError:</span>
            <span class="s1">val = self.registry.value = self.createfunc()</span>
            <span class="s2">return </span><span class="s1">val</span>

    <span class="s2">def </span><span class="s1">has(self):</span>
        <span class="s2">return </span><span class="s1">hasattr(self.registry, </span><span class="s3">&quot;value&quot;</span><span class="s1">)</span>

    <span class="s2">def </span><span class="s1">set(self, obj):</span>
        <span class="s1">self.registry.value = obj</span>

    <span class="s2">def </span><span class="s1">clear(self):</span>
        <span class="s2">try</span><span class="s1">:</span>
            <span class="s2">del </span><span class="s1">self.registry.value</span>
        <span class="s2">except </span><span class="s1">AttributeError:</span>
            <span class="s2">pass</span>


<span class="s2">def </span><span class="s1">has_dupes(sequence, target):</span>
    <span class="s0">&quot;&quot;&quot;Given a sequence and search object, return True if there's more 
    than one, False if zero or one of them. 
 
 
    &quot;&quot;&quot;</span>
    <span class="s0"># compare to .index version below, this version introduces less function</span>
    <span class="s0"># overhead and is usually the same speed.  At 15000 items (way bigger than</span>
    <span class="s0"># a relationship-bound collection in memory usually is) it begins to</span>
    <span class="s0"># fall behind the other version only by microseconds.</span>
    <span class="s1">c = </span><span class="s4">0</span>
    <span class="s2">for </span><span class="s1">item </span><span class="s2">in </span><span class="s1">sequence:</span>
        <span class="s2">if </span><span class="s1">item </span><span class="s2">is </span><span class="s1">target:</span>
            <span class="s1">c += </span><span class="s4">1</span>
            <span class="s2">if </span><span class="s1">c &gt; </span><span class="s4">1</span><span class="s1">:</span>
                <span class="s2">return True</span>
    <span class="s2">return False</span>


<span class="s0"># .index version.  the two __contains__ calls as well</span>
<span class="s0"># as .index() and isinstance() slow this down.</span>
<span class="s0"># def has_dupes(sequence, target):</span>
<span class="s0">#    if target not in sequence:</span>
<span class="s0">#        return False</span>
<span class="s0">#    elif not isinstance(sequence, collections_abc.Sequence):</span>
<span class="s0">#        return False</span>
<span class="s0">#</span>
<span class="s0">#    idx = sequence.index(target)</span>
<span class="s0">#    return target in sequence[idx + 1:]</span>
</pre>
</body>
</html>